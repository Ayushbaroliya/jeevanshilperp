# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: finance.spec.js >> Finance Module >> should navigate between finance tabs
- Location: e2e\finance.spec.js:14:3

# Error details

```
Test timeout of 30000ms exceeded while running "beforeEach" hook.
```

```
Error: page.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('text=Jeevan Shilp Public School')
    - locator resolved to 2 elements. Proceeding with the first one: <option value="SCH_01">Jeevan Shilp Public School (JSPS)</option>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is not visible
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is not visible
    - retrying click action
      - waiting 100ms
    53 × waiting for element to be visible, enabled and stable
       - element is not visible
     - retrying click action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - generic [ref=e5]:
      - generic [ref=e11]:
        - generic [ref=e12]: Jeevanshilp Group
        - generic [ref=e13]: School Governance
      - combobox [ref=e14]:
        - option "All 3 School Campuses" [selected]
        - option "Jeevan Shilp Public School (JSPS)"
        - option "Jeevan Shilp Inter College (JSIC)"
        - option "Jeevan Shilp Adarsh Shala (JSB2)"
    - textbox [ref=e16]
    - generic [ref=e17]:
      - button "🇮🇳 हिंदी" [ref=e18] [cursor=pointer]
      - button "Toggle Dark Mode" [ref=e19] [cursor=pointer]
      - generic [ref=e22]: Group Owner / Super Admin
      - button "Logout" [ref=e27] [cursor=pointer]
  - generic [ref=e31]:
    - complementary [ref=e32]:
      - generic [ref=e33]: Main Navigation
      - navigation [ref=e34]:
        - button "Dashboard" [ref=e35] [cursor=pointer]
        - button "Students Directory" [ref=e42] [cursor=pointer]
        - button "Fees & Finance" [active] [ref=e49] [cursor=pointer]
        - button "Academics & Grades" [ref=e53] [cursor=pointer]
        - button "Staff & Salary" [ref=e58] [cursor=pointer]
        - button "School Settings & Governance" [ref=e63] [cursor=pointer]
    - main [ref=e68]:
      - generic [ref=e69]:
        - generic [ref=e70]:
          - button [ref=e71] [cursor=pointer]
          - heading "Fees & Finance" [level=1] [ref=e74]
        - generic [ref=e75]:
          - heading "Select Branch for Finance Management" [level=2] [ref=e76]
          - paragraph [ref=e77]: Please select a specific school branch to view and manage fee collection, invoices, and dues.
          - generic [ref=e78]:
            - generic [ref=e79] [cursor=pointer]:
              - generic [ref=e82]: Jeevan Shilp Public School
              - generic [ref=e83]: Main Branch • JSPS
            - generic [ref=e84] [cursor=pointer]:
              - generic [ref=e87]: Jeevan Shilp Inter College
              - generic [ref=e88]: College Wing • JSIC
            - generic [ref=e89] [cursor=pointer]:
              - generic [ref=e92]: Jeevan Shilp Adarsh Shala
              - generic [ref=e93]: Branch 2 • JSB2
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | test.describe('Finance Module', () => {
  4  | 
  5  |   test.beforeEach(async ({ page }) => {
  6  |     await page.goto('/');
  7  |     await page.click('#e2e-owner-login');
  8  |     await expect(page.locator('text=Group Owner / Super Admin')).toBeVisible();
  9  |     await page.click('button:has-text("Fees & Finance")');
> 10 |     await page.click('text=Jeevan Shilp Public School');
     |                ^ Error: page.click: Test timeout of 30000ms exceeded.
  11 |     await expect(page.locator('h1', { hasText: 'Classwise Due Fees Directory' })).toBeVisible();
  12 |   });
  13 | 
  14 |   test('should navigate between finance tabs', async ({ page }) => {
  15 |     await expect(page.locator('h1', { hasText: 'Classwise Due Fees Directory' })).toBeVisible();
  16 | 
  17 |     await page.click('button:has-text("Collect Fee & Cut Receipt")');
  18 |     await expect(page.locator('h2', { hasText: 'Record New Fee Payment' })).toBeVisible();
  19 | 
  20 |     await page.click('button:has-text("Issued Receipts History")');
  21 |     await expect(page.locator('h2', { hasText: 'Fee Invoices & Receipts' })).toBeVisible();
  22 |     
  23 |     await page.click('button:has-text("All Pending Fees List")');
  24 |     await expect(page.locator('button:has-text("All Pending Fees List")')).toBeVisible();
  25 |   });
  26 | 
  27 |   test('should open collect fee tab when clicking Collect', async ({ page }) => {
  28 |     // Click Collect for the first student in the list
  29 |     await page.waitForSelector('button:has-text("Collect")');
  30 |     await page.locator('button:has-text("Collect")').first().click();
  31 |     
  32 |     // Verify it navigated to Record Payment tab
  33 |     await expect(page.locator('h2', { hasText: 'Record New Fee Payment' })).toBeVisible();
  34 |     await expect(page.locator('button:has-text("Issue Fee Receipt")')).toBeVisible();
  35 |   });
  36 | 
  37 | });
  38 | 
```