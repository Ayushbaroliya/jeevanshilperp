# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: academics.spec.js >> Academics Module >> should show gradebook inputs
- Location: e2e\academics.spec.js:27:3

# Error details

```
Test timeout of 30000ms exceeded while running "beforeEach" hook.
```

```
Error: page.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('text=Jeevan Shilp Public School')
    - locator resolved to 2 elements. Proceeding with the first one: <option value="SCH_01">Jeevan Shilp Public School (JSPS)</option>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is not visible
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is not visible
    - retrying click action
      - waiting 100ms
    53 × waiting for element to be visible, enabled and stable
       - element is not visible
     - retrying click action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - generic [ref=e5]:
      - generic [ref=e11]:
        - generic [ref=e12]: Jeevanshilp Group
        - generic [ref=e13]: School Governance
      - combobox [ref=e14]:
        - option "All 3 School Campuses" [selected]
        - option "Jeevan Shilp Public School (JSPS)"
        - option "Jeevan Shilp Inter College (JSIC)"
        - option "Jeevan Shilp Adarsh Shala (JSB2)"
    - textbox [ref=e16]
    - generic [ref=e17]:
      - button "🇮🇳 हिंदी" [ref=e18] [cursor=pointer]
      - button "Toggle Dark Mode" [ref=e19] [cursor=pointer]
      - generic [ref=e22]: Group Owner / Super Admin
      - button "Logout" [ref=e27] [cursor=pointer]
  - generic [ref=e31]:
    - complementary [ref=e32]:
      - generic [ref=e33]: Main Navigation
      - navigation [ref=e34]:
        - button "Dashboard" [ref=e35] [cursor=pointer]
        - button "Students Directory" [ref=e42] [cursor=pointer]
        - button "Fees & Finance" [ref=e49] [cursor=pointer]
        - button "Academics & Grades" [active] [ref=e53] [cursor=pointer]
        - button "Staff & Salary" [ref=e58] [cursor=pointer]
        - button "School Settings & Governance" [ref=e63] [cursor=pointer]
    - main [ref=e68]:
      - generic [ref=e69]:
        - heading "Academics & Activities" [level=1] [ref=e71]
        - generic [ref=e72]:
          - heading "Select Branch for Academics" [level=2] [ref=e73]
          - paragraph [ref=e74]: Please select a specific school branch to manage attendance, grades, and activities.
          - generic [ref=e75]:
            - generic [ref=e76] [cursor=pointer]:
              - generic [ref=e79]: Jeevan Shilp Public School
              - generic [ref=e80]: Main Branch • JSPS
            - generic [ref=e81] [cursor=pointer]:
              - generic [ref=e84]: Jeevan Shilp Inter College
              - generic [ref=e85]: College Wing • JSIC
            - generic [ref=e86] [cursor=pointer]:
              - generic [ref=e89]: Jeevan Shilp Adarsh Shala
              - generic [ref=e90]: Branch 2 • JSB2
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | test.describe('Academics Module', () => {
  4  | 
  5  |   test.beforeEach(async ({ page }) => {
  6  |     await page.goto('/');
  7  |     await page.click('#e2e-owner-login');
  8  |     await expect(page.locator('text=Group Owner / Super Admin')).toBeVisible();
  9  |     await page.click('button:has-text("Academics & Grades")');
> 10 |     await page.click('text=Jeevan Shilp Public School');
     |                ^ Error: page.click: Test timeout of 30000ms exceeded.
  11 |     await expect(page.locator('h1', { hasText: 'Academics' })).toBeVisible();
  12 |   });
  13 | 
  14 |   test('should navigate between academics tabs', async ({ page }) => {
  15 |     // Daily Attendance is default
  16 |     await expect(page.locator('button:has-text("Mark All Present")')).toBeVisible();
  17 | 
  18 |     // Go to Gradebook
  19 |     await page.click('button:has-text("Subject Gradebook & Marks")');
  20 |     await expect(page.locator('h2', { hasText: 'Gradebook' })).toBeVisible();
  21 |     
  22 |     // Go back to Attendance
  23 |     await page.click('button:has-text("Daily Attendance")');
  24 |     await expect(page.locator('button:has-text("Mark All Absent")')).toBeVisible();
  25 |   });
  26 | 
  27 |   test('should show gradebook inputs', async ({ page }) => {
  28 |     await page.click('button:has-text("Subject Gradebook & Marks")');
  29 |     
  30 |     // Check if Save button appears
  31 |     await expect(page.locator('button:has-text("Save")')).toBeVisible();
  32 |   });
  33 | 
  34 | });
  35 | 
```