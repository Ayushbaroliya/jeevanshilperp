# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dashboard.spec.js >> Dashboard Interactions >> should navigate to Settings from staff permissions action
- Location: e2e\dashboard.spec.js:26:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('button.btn-secondary:has-text("Staff & Permissions")')

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - generic [ref=e5]:
      - generic [ref=e11]:
        - generic [ref=e12]: Jeevanshilp Group
        - generic [ref=e13]: School Governance
      - combobox [ref=e14]:
        - option "All 3 School Campuses"
        - option "Jeevan Shilp Public School (JSPS)" [selected]
        - option "Jeevan Shilp Inter College (JSIC)"
        - option "Jeevan Shilp Adarsh Shala (JSB2)"
    - textbox [ref=e16]
    - generic [ref=e17]:
      - button "🇮🇳 हिंदी" [ref=e18] [cursor=pointer]
      - button "Toggle Dark Mode" [ref=e19] [cursor=pointer]
      - generic [ref=e22]: Group Owner / Super Admin
      - button "Logout" [ref=e27] [cursor=pointer]
  - generic [ref=e31]:
    - complementary [ref=e32]:
      - generic [ref=e33]: Main Navigation
      - navigation [ref=e34]:
        - button "Dashboard" [ref=e35] [cursor=pointer]
        - button "Students Directory" [ref=e42] [cursor=pointer]
        - button "Fees & Finance" [ref=e49] [cursor=pointer]
        - button "Academics & Grades" [ref=e53] [cursor=pointer]
        - button "Staff & Salary" [ref=e58] [cursor=pointer]
        - button "School Settings & Governance" [ref=e63] [cursor=pointer]
    - main [ref=e68]:
      - generic [ref=e69]:
        - generic [ref=e71]:
          - heading "Jeevan Shilp Public School" [level=1] [ref=e72]
          - paragraph [ref=e73]: Executive overview, financial metrics, and operational hub
        - generic [ref=e74]:
          - button "Overview" [ref=e75] [cursor=pointer]
          - button "Finance" [ref=e76] [cursor=pointer]
          - button "Staff & Actions" [ref=e77] [cursor=pointer]
        - generic [ref=e78]:
          - generic [ref=e79] [cursor=pointer]:
            - generic [ref=e80]:
              - generic [ref=e81]: Consolidated
              - generic [ref=e82]: ALL 3
            - generic [ref=e83]: All 3 Schools Combined
            - generic [ref=e84]: 0 Students
            - generic [ref=e85]: Real-time aggregated view
          - generic [ref=e86] [cursor=pointer]:
            - generic [ref=e87]:
              - generic [ref=e88]: Campus
              - generic [ref=e89]: ACTIVE
            - generic [ref=e90]: Jeevan Shilp Public School
            - generic [ref=e91]: 0 Students
          - generic [ref=e92] [cursor=pointer]:
            - generic [ref=e93]:
              - generic [ref=e94]: Campus
              - generic [ref=e95]: JSIC
            - generic [ref=e96]: Jeevan Shilp Inter College
            - generic [ref=e97]: 0 Students
          - generic [ref=e98] [cursor=pointer]:
            - generic [ref=e99]:
              - generic [ref=e100]: Campus
              - generic [ref=e101]: JSB2
            - generic [ref=e102]: Jeevan Shilp Adarsh Shala
            - generic [ref=e103]: 0 Students
        - generic [ref=e104]:
          - heading "Monthly Revenue & Expenses (₹)" [level=2] [ref=e106]
          - generic [ref=e110]:
            - list [ref=e112]:
              - listitem [ref=e113]:
                - img "Fee Revenue legend icon" [ref=e114]
                - text: Fee Revenue
              - listitem [ref=e116]:
                - img "Salary Expenses legend icon" [ref=e117]
                - text: Salary Expenses
            - application [ref=e119]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | test.describe('Dashboard Interactions', () => {
  4  | 
  5  |   test.beforeEach(async ({ page }) => {
  6  |     // Login as Admin
  7  |     await page.goto('/');
  8  |     await page.click('#e2e-owner-login');
  9  |     await expect(page.locator('text=Group Owner / Super Admin')).toBeVisible();
  10 |   });
  11 | 
  12 |   test('should navigate to Students Directory from quick actions', async ({ page }) => {
  13 |     await page.click('div.glass-card:has-text("Jeevan Shilp Public School")');
  14 |     await page.click('button.btn-primary:has-text("Register Student")');
  15 |     await expect(page.locator('h1.page-title', { hasText: 'Classes Directory' })).toBeVisible();
  16 |   });
  17 | 
  18 |   test('should navigate to Finance from collect fee action', async ({ page }) => {
  19 |     // Navigate back to dashboard to ensure we are on the right page
  20 |     await page.click('button:has-text("Dashboard")');
  21 |     await page.click('div.glass-card:has-text("Jeevan Shilp Public School")');
  22 |     await page.click('button.btn-secondary:has-text("Collect Fee")');
  23 |     await expect(page.locator('h1', { hasText: 'Classwise Due Fees Directory' })).toBeVisible();
  24 |   });
  25 | 
  26 |   test('should navigate to Settings from staff permissions action', async ({ page }) => {
  27 |     await page.click('button:has-text("Dashboard")');
  28 |     await page.click('div.glass-card:has-text("Jeevan Shilp Public School")');
> 29 |     await page.click('button.btn-secondary:has-text("Staff & Permissions")');
     |                ^ Error: page.click: Test timeout of 30000ms exceeded.
  30 |     await expect(page.locator('h1', { hasText: 'School Settings & Governance' })).toBeVisible();
  31 |   });
  32 | 
  33 |   test('should change selected campus data when clicking campus cards', async ({ page }) => {
  34 |     // Check initial state (All 3 Combined)
  35 |     await expect(page.locator('text=All 3 Schools Combined')).toBeVisible();
  36 |     
  37 |     // Click on Campus 1
  38 |     await page.click('div.glass-card:has-text("Jeevan Shilp Public School")');
  39 |     // Verify title changed
  40 |     await expect(page.locator('h1.page-title', { hasText: 'Jeevan Shilp Public School' })).toBeVisible();
  41 |     
  42 |     // Click on Campus 2
  43 |     await page.click('div.glass-card:has-text("Jeevan Shilp Inter College")');
  44 |     await expect(page.locator('h1.page-title', { hasText: 'Jeevan Shilp Inter College' })).toBeVisible();
  45 |   });
  46 | 
  47 | });
  48 | 
```