# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: students.spec.js >> Students Directory and Ledger >> should filter students by section
- Location: e2e\students.spec.js:44:3

# Error details

```
Test timeout of 30000ms exceeded while running "beforeEach" hook.
```

```
Error: page.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('text=Jeevan Shilp Public School')
    - locator resolved to 2 elements. Proceeding with the first one: <option value="SCH_01">Jeevan Shilp Public School (JSPS)</option>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is not visible
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is not visible
    - retrying click action
      - waiting 100ms
    55 × waiting for element to be visible, enabled and stable
       - element is not visible
     - retrying click action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - generic [ref=e5]:
      - generic [ref=e11]:
        - generic [ref=e12]: Jeevanshilp Group
        - generic [ref=e13]: School Governance
      - combobox [ref=e14]:
        - option "All 3 School Campuses" [selected]
        - option "Jeevan Shilp Public School (JSPS)"
        - option "Jeevan Shilp Inter College (JSIC)"
        - option "Jeevan Shilp Adarsh Shala (JSB2)"
    - textbox [ref=e16]
    - generic [ref=e17]:
      - button "🇮🇳 हिंदी" [ref=e18] [cursor=pointer]
      - button "Toggle Dark Mode" [ref=e19] [cursor=pointer]
      - generic [ref=e22]: Group Owner / Super Admin
      - button "Logout" [ref=e27] [cursor=pointer]
  - generic [ref=e31]:
    - complementary [ref=e32]:
      - generic [ref=e33]: Main Navigation
      - navigation [ref=e34]:
        - button "Dashboard" [ref=e35] [cursor=pointer]
        - button "Students Directory" [active] [ref=e42] [cursor=pointer]
        - button "Fees & Finance" [ref=e49] [cursor=pointer]
        - button "Academics & Grades" [ref=e53] [cursor=pointer]
        - button "Staff & Salary" [ref=e58] [cursor=pointer]
        - button "School Settings & Governance" [ref=e63] [cursor=pointer]
    - main [ref=e68]:
      - generic [ref=e69]:
        - generic [ref=e70]:
          - button [ref=e71] [cursor=pointer]
          - heading "Student Directory" [level=1] [ref=e74]
        - generic [ref=e75]:
          - heading "Select Branch for Student Directory" [level=2] [ref=e76]
          - paragraph [ref=e77]: Please select a specific school branch to view and manage its students.
          - generic [ref=e78]:
            - generic [ref=e79] [cursor=pointer]:
              - generic [ref=e82]: Jeevan Shilp Public School
              - generic [ref=e83]: Main Branch • JSPS
            - generic [ref=e84] [cursor=pointer]:
              - generic [ref=e87]: Jeevan Shilp Inter College
              - generic [ref=e88]: College Wing • JSIC
            - generic [ref=e89] [cursor=pointer]:
              - generic [ref=e92]: Jeevan Shilp Adarsh Shala
              - generic [ref=e93]: Branch 2 • JSB2
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | test.describe('Students Directory and Ledger', () => {
  4  | 
  5  |   test.beforeEach(async ({ page }) => {
  6  |     await page.goto('/');
  7  |     await page.click('#e2e-owner-login');
  8  |     await expect(page.locator('text=Group Owner / Super Admin')).toBeVisible();
  9  |     await page.click('button:has-text("Students Directory")');
> 10 |     await page.click('text=Jeevan Shilp Public School');
     |                ^ Error: page.click: Test timeout of 30000ms exceeded.
  11 |     await expect(page.locator('h1.page-title', { hasText: 'Classes Directory' })).toBeVisible();
  12 |   });
  13 | 
  14 |   test('should open and close the Add Student section', async ({ page }) => {
  15 |     // Click on Class 1 first to be able to add a student
  16 |     await page.click('text=Class 1');
  17 |     await expect(page.locator('h1.page-title', { hasText: 'Class 1 - Students' })).toBeVisible();
  18 | 
  19 |     await page.click('button:has-text("Add Student")');
  20 |     
  21 |     // Verify add student form is visible
  22 |     await expect(page.locator('h2', { hasText: 'Student Registration Details' })).toBeVisible();
  23 |     
  24 |     // Fill out some basic fields
  25 |     await page.fill('input[placeholder="e.g. Aarav Patel"]', 'Test Student');
  26 |     await page.fill('input[placeholder="e.g. 42"]', '99');
  27 |     
  28 |     // Cancel
  29 |     await page.click('button:has-text("Cancel")');
  30 |     await expect(page.locator('h2', { hasText: 'Student Registration Details' })).not.toBeVisible();
  31 |   });
  32 | 
  33 |   test('should open a student ledger when clicking on a student row', async ({ page }) => {
  34 |     // Select Class 1
  35 |     await page.click('text=Class 1');
  36 |     
  37 |     // Click the first student in the list
  38 |     await page.locator('.glass-card.flex-responsive').first().click();
  39 |     
  40 |     // Should navigate to ledger
  41 |     await expect(page.locator('button:has-text("Back to Directory")')).toBeVisible();
  42 |   });
  43 | 
  44 |   test('should filter students by section', async ({ page }) => {
  45 |     // Select Class 1
  46 |     await page.click('text=Class 1');
  47 |     
  48 |     // Filter by Section B
  49 |     await page.selectOption('select:has-text("All Sections")', 'Section B');
  50 |     
  51 |     // Ensure something is rendered (either students or 'No students found')
  52 |     await expect(page.locator('.glass-card').first()).toBeVisible();
  53 |   });
  54 | 
  55 | });
  56 | 
```