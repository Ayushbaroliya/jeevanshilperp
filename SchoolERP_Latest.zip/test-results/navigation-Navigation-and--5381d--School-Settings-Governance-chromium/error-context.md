# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: navigation.spec.js >> Navigation and Sidebar Routing >> should navigate to School Settings & Governance
- Location: e2e\navigation.spec.js:40:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('text=Jeevan Shilp Public School')
    - locator resolved to 2 elements. Proceeding with the first one: <option value="SCH_01">Jeevan Shilp Public School (JSPS)</option>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is not visible
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is not visible
    - retrying click action
      - waiting 100ms
    56 × waiting for element to be visible, enabled and stable
       - element is not visible
     - retrying click action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - generic [ref=e5]:
      - generic [ref=e11]:
        - generic [ref=e12]: Jeevanshilp Group
        - generic [ref=e13]: School Governance
      - combobox [ref=e14]:
        - option "All 3 School Campuses" [selected]
        - option "Jeevan Shilp Public School (JSPS)"
        - option "Jeevan Shilp Inter College (JSIC)"
        - option "Jeevan Shilp Adarsh Shala (JSB2)"
    - textbox [ref=e16]
    - generic [ref=e17]:
      - button "🇮🇳 हिंदी" [ref=e18] [cursor=pointer]
      - button "Toggle Dark Mode" [ref=e19] [cursor=pointer]
      - generic [ref=e22]: Group Owner / Super Admin
      - button "Logout" [ref=e27] [cursor=pointer]
  - generic [ref=e31]:
    - complementary [ref=e32]:
      - generic [ref=e33]: Main Navigation
      - navigation [ref=e34]:
        - button "Dashboard" [ref=e35] [cursor=pointer]
        - button "Students Directory" [ref=e42] [cursor=pointer]
        - button "Fees & Finance" [ref=e49] [cursor=pointer]
        - button "Academics & Grades" [ref=e53] [cursor=pointer]
        - button "Staff & Salary" [ref=e58] [cursor=pointer]
        - button "School Settings & Governance" [active] [ref=e63] [cursor=pointer]
    - main [ref=e68]:
      - generic [ref=e69]:
        - heading "School Settings & Staff" [level=1] [ref=e71]
        - generic [ref=e72]:
          - heading "Select Branch for Configuration" [level=2] [ref=e73]
          - paragraph [ref=e74]: Please select a specific school branch to manage its staff, teachers, and assignments.
          - generic [ref=e75]:
            - generic [ref=e76] [cursor=pointer]:
              - generic [ref=e79]: Jeevan Shilp Public School
              - generic [ref=e80]: Main Branch • JSPS
            - generic [ref=e81] [cursor=pointer]:
              - generic [ref=e84]: Jeevan Shilp Inter College
              - generic [ref=e85]: College Wing • JSIC
            - generic [ref=e86] [cursor=pointer]:
              - generic [ref=e89]: Jeevan Shilp Adarsh Shala
              - generic [ref=e90]: Branch 2 • JSB2
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | test.describe('Navigation and Sidebar Routing', () => {
  4  | 
  5  |   test.beforeEach(async ({ page }) => {
  6  |     // Login as Admin before each navigation test
  7  |     await page.goto('/');
  8  |     await page.click('#e2e-owner-login');
  9  |     // Wait for Dashboard to load
  10 |     await expect(page.locator('text=Group Owner / Super Admin')).toBeVisible();
  11 |   });
  12 | 
  13 |   test('should navigate to Students Directory', async ({ page }) => {
  14 |     await page.click('button:has-text("Students Directory")');
  15 |     await page.click('text=Jeevan Shilp Public School');
  16 |     // Verify it navigates correctly
  17 |     await expect(page.locator('h1.page-title', { hasText: 'Classes Directory' })).toBeVisible();
  18 |   });
  19 | 
  20 |   test('should navigate to Fees & Finance', async ({ page }) => {
  21 |     await page.click('button:has-text("Fees & Finance")');
  22 |     await page.click('text=Jeevan Shilp Public School');
  23 |     await expect(page.locator('h1', { hasText: 'Classwise Due Fees Directory' })).toBeVisible();
  24 |     await expect(page.locator('button:has-text("Collect Fee & Cut Receipt")')).toBeVisible();
  25 |   });
  26 | 
  27 |   test('should navigate to Academics & Grades', async ({ page }) => {
  28 |     await page.click('button:has-text("Academics & Grades")');
  29 |     await page.click('text=Jeevan Shilp Public School');
  30 |     await expect(page.locator('h1', { hasText: 'Academics' })).toBeVisible();
  31 |     await expect(page.locator('button:has-text("Daily Attendance")')).toBeVisible();
  32 |   });
  33 | 
  34 |   test('should navigate to Staff & Salary', async ({ page }) => {
  35 |     await page.click('button:has-text("Staff & Salary")');
  36 |     await page.click('text=Jeevan Shilp Public School');
  37 |     await expect(page.locator('h1.page-title', { hasText: 'Staff Salary & Attendance' })).toBeVisible();
  38 |   });
  39 | 
  40 |   test('should navigate to School Settings & Governance', async ({ page }) => {
  41 |     await page.click('button:has-text("School Settings & Governance")');
> 42 |     await page.click('text=Jeevan Shilp Public School');
     |                ^ Error: page.click: Test timeout of 30000ms exceeded.
  43 |     await expect(page.locator('h1', { hasText: 'School Settings & Governance' })).toBeVisible();
  44 |     await expect(page.locator('button:has-text("Class & Fee Structure")')).toBeVisible();
  45 |   });
  46 | 
  47 |   test('should navigate back to Dashboard', async ({ page }) => {
  48 |     await page.click('button:has-text("Students Directory")'); // Navigate away first
  49 |     await page.click('button:has-text("Dashboard")');
  50 |     await expect(page.locator('text=Executive overview')).toBeVisible();
  51 |   });
  52 | 
  53 | });
  54 | 
```