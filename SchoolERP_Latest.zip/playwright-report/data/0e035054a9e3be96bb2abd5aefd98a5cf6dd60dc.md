# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: staff.spec.js >> Staff Module >> should navigate between staff tabs
- Location: e2e\staff.spec.js:14:3

# Error details

```
Test timeout of 30000ms exceeded while running "beforeEach" hook.
```

```
Error: page.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('text=Jeevan Shilp Public School')
    - locator resolved to <option value="SCH_01">Jeevan Shilp Public School (JSPS)</option>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is not visible
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is not visible
    - retrying click action
      - waiting 100ms
    55 × waiting for element to be visible, enabled and stable
       - element is not visible
     - retrying click action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - generic [ref=e5]:
      - generic [ref=e11]:
        - generic [ref=e12]: Jeevanshilp Group
        - generic [ref=e13]: School Governance
      - combobox [ref=e14]:
        - option "All 3 School Campuses" [selected]
        - option "Jeevan Shilp Public School (JSPS)"
        - option "Jeevan Shilp Inter College (JSIC)"
        - option "Jeevan Shilp Adarsh Shala (JSB2)"
    - textbox [ref=e16]
    - generic [ref=e17]:
      - button "🇮🇳 हिंदी" [ref=e18] [cursor=pointer]
      - button "Toggle Dark Mode" [ref=e19] [cursor=pointer]
      - generic [ref=e22]: Group Owner / Super Admin
      - button "Logout" [ref=e27] [cursor=pointer]
  - generic [ref=e31]:
    - complementary [ref=e32]:
      - generic [ref=e33]: Main Navigation
      - navigation [ref=e34]:
        - button "Dashboard" [ref=e35] [cursor=pointer]
        - button "Students Directory" [ref=e42] [cursor=pointer]
        - button "Fees & Finance" [ref=e49] [cursor=pointer]
        - button "Academics & Grades" [ref=e53] [cursor=pointer]
        - button "Staff & Salary" [active] [ref=e58] [cursor=pointer]
        - button "School Settings & Governance" [ref=e63] [cursor=pointer]
    - main [ref=e68]:
      - generic [ref=e69]:
        - generic [ref=e70]:
          - generic [ref=e71]:
            - heading "Staff Salary & Attendance" [level=1] [ref=e72]
            - paragraph [ref=e75]: Manage monthly payroll, track staff attendance, and generate payslips
          - generic [ref=e76]:
            - button "Export Report" [disabled] [ref=e77] [cursor=pointer]
            - button "Process Payroll" [disabled] [ref=e81]
        - generic [ref=e83]:
          - button "Mark Attendance" [ref=e84] [cursor=pointer]
          - button "Salary Management" [ref=e89] [cursor=pointer]
          - button "Process Payroll" [ref=e92] [cursor=pointer]
        - generic [ref=e98]:
          - generic [ref=e99]: Consolidated HR View Active
          - generic [ref=e100]: You are viewing staff data across all campuses. To process payroll or mark attendance, please select a specific campus.
        - status [ref=e101]: Unable to load staff from the database.
        - generic [ref=e102]:
          - generic [ref=e103]:
            - heading "Today's Staff Roster (8/21/2026)" [level=3] [ref=e104]
            - button "Save All Attendance" [disabled] [ref=e107]
          - table [ref=e113]:
            - rowgroup [ref=e114]:
              - row [ref=e115]:
                - columnheader "Staff Name" [ref=e116]
                - columnheader "Department" [ref=e117]
                - columnheader "Check In" [ref=e118]
                - columnheader "Check Out" [ref=e119]
                - columnheader "Attendance Status" [ref=e120]
            - rowgroup
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | test.describe('Staff Module', () => {
  4  | 
  5  |   test.beforeEach(async ({ page }) => {
  6  |     await page.goto('/');
  7  |     await page.click('#e2e-owner-login');
  8  |     await expect(page.locator('text=Group Owner / Super Admin')).toBeVisible();
  9  |     await page.click('button:has-text("Staff & Salary")');
> 10 |     await page.click('text=Jeevan Shilp Public School');
     |                ^ Error: page.click: Test timeout of 30000ms exceeded.
  11 |     await expect(page.locator('h1.page-title', { hasText: 'Staff Salary & Attendance' })).toBeVisible();
  12 |   });
  13 | 
  14 |   test('should navigate between staff tabs', async ({ page }) => {
  15 |     await expect(page.locator('h3', { hasText: 'Today\'s Staff Roster' })).toBeVisible();
  16 | 
  17 |     await page.click('button:has-text("Salary Management")');
  18 |     await expect(page.locator('button:has-text("Filter by Dept")')).toBeVisible();
  19 |     
  20 |     await page.click('button:has-text("Process Payroll")');
  21 |     await expect(page.locator('h3', { hasText: 'Run Monthly Payroll' })).toBeVisible();
  22 |   });
  23 | 
  24 | });
  25 | 
```